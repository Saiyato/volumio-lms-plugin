package Media::Scan::Audio;

use strict;
use base qw(Media::Scan::Result);

# Implementation is in xs/Audio.xs and xs/Result.xs

1;